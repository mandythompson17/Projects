//--------------------------------------------------------------//
Default v1.2.1 by Templatesuper
templatesuper.com | @templatesuper | copyright (c) 2014
//--------------------------------------------------------------//

Default is a HTML super premium modern one page responsive template. 



//-----------------------------------------------//
## USAGE
//-----------------------------------------------//
1. Open file "contactus.php" with text editor.
2. Replace "YOUR@EMAIL.COM" with your email address.
3. Upload all file to your server directory.
4. Open your browser and type your url.

nb:
To add your maps address:
1. Goto https://www.google.com/maps/
2. Embed your maps address
3. Put your script and replace "IFRAME MAPS" in index.html line 276



//-----------------------------------------------//
## CHANGELOGS
//-----------------------------------------------//


1.2.1 (Feb, 2015)
 - Compatible Bootstrap 3.3

1.2.0 (Mar 12, 2014)
- Add Ajax form submit "Contact Us" (NEW)
- Fix css form input (height) "Contact Us" on Internet Explorer & Firefox

1.0.0 (Feb 28, 2014)
 - Initial release



//-----------------------------------------------//
## CREDITS 
//-----------------------------------------------//

WOW.js - https://github.com/matthieua/WOW
animated.css - https://github.com/daneden/animate.css
Font Awesome - http://fortawesome.github.com/Font-Awesome

Images:
The Diary with Black iPhone - http://picjumbo.com/the-diary-with-black-iphone/
MacBook and clutter? - http://picjumbo.com/macbook-and-clutter/
Holding iPhone 5S Gold in Cafe - http://picjumbo.com/holding-iphone-5s-gold-in-cafe/
Another Hand with an iPhone 5S - http://picjumbo.com/another-hand-with-an-iphone-5s/
Comparing iPhone 5S with iPhone 5 - http://picjumbo.com/comparing-iphone-5s-with-iphone-5/
People Umbrellas Standing Rain Waiting - http://pixabay.com/en/people-umbrellas-standing-rain-246231/
Girl Joy Smiling Happy Children Kid - http://pixabay.com/en/girl-joy-smiling-happy-children-206143/
Smiling Kid People Look Young Face Portrait - http://pixabay.com/en/smiling-kid-people-look-young-103035/
The man in the woods - http://www.publicdomainpictures.net/view-image.php?image=29978&picture=the-man-in-the-woods



